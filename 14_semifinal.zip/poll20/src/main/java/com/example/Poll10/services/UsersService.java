package com.example.Poll10.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.Poll10.entity.Users;
import com.example.Poll10.repositories.UsersRepository;

@Service
public class UsersService {
	@Autowired
	private UsersRepository usersRepo;
	
	 public void saveOrUpdate(Users use)
	 {
		// System.out.println("You entered:= " + pollName);
		 usersRepo.save(use);
	 }
	 public Users getbyid(int id) {
		return usersRepo.findById(id).get();
		 
	 }

}
