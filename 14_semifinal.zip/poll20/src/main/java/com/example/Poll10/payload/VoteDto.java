package com.example.Poll10.payload;

import com.example.Poll10.entity.PollOption;
import com.example.Poll10.entity.Users;

public class VoteDto {

    
    private int voteId;
	
	
    private Users users;
	
	
    private PollOption polloption;


	public int getVoteId() {
		return voteId;
	}


	public void setVoteId(int voteId) {
		this.voteId = voteId;
	}


	public Users getUsers() {
		return users;
	}


	public void setUsers(Users users) {
		this.users = users;
	}


	public PollOption getPolloption() {
		return polloption;
	}


	public void setPolloption(PollOption polloption) {
		this.polloption = polloption;
	}
    

}
