package com.example.Poll10.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.Poll10.entity.PollOption;

@Repository
public interface PollOptionRepository extends JpaRepository<PollOption,Integer> {
	
	//@Query("select count(u.user_age) from Users u where useId=:ud")
	//Integer age(@Param("ud") Integer uId);
    //SELECT * FROM poll10.user WHERE use_id!=1;
	
	@Query("select p from PollOption p where poll_id!=:pd")
	List<PollOption> resList(@Param("pd") Integer pId);
	
	//@Query("SELECT e FROM postData e INNER JOIN e.user t where t.country!=:c")
	//List<postData> countryWisePost(@Param("c") String country);
}
