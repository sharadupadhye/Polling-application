package com.example.Poll10.entity;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "user")
@DynamicUpdate
@NoArgsConstructor
@Getter
@Setter
public class Users {
	@Id
    @Column(name="useId")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int useId;
    
	@Column(name="user_name")
    private String user_name;
    
    @Column(name="user_password")
    private String user_password;
    
    @Column(name="user_role")
    private String  user_role;
    
    @Column(name="user_age")
    private int user_age;
    
    @Column(name="user_location")
    private String  user_location;
    @JsonIgnore
    @OneToMany(mappedBy = "users",cascade = CascadeType.ALL)
	 private List<Vote> votes = new ArrayList<>();

	

	public int getUseId() {
		return useId;
	}

	public void setUseId(int useId) {
		this.useId = useId;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getUser_password() {
		return user_password;
	}

	public void setUser_password(String user_password) {
		this.user_password = user_password;
	}

	public String getUser_role() {
		return user_role;
	}

	public void setUser_role(String user_role) {
		this.user_role = user_role;
	}

	public int getUser_age() {
		return user_age;
	}

	public void setUser_age(int user_age) {
		this.user_age = user_age;
	}

	public String getUser_location() {
		return user_location;
	}

	public void setUser_location(String user_location) {
		this.user_location = user_location;
	}

	public List<Vote> getVotes() {
		return votes;
	}

	public void setVotes(List<Vote> votes) {
		this.votes = votes;
	}
    
}
