package com.example.Poll10.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.tools.DocumentationTool.Location;

import org.hibernate.annotations.DynamicUpdate;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "locationrestriction")
@DynamicUpdate
@NoArgsConstructor
@Getter
@Setter
public class LocationRestriction {
	@Id
    @Column(name="locationID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int locationID;
 //------------------------------------------------------------------------  
	@Column(name = "Restriction ")
	@Enumerated(EnumType.STRING)
	private Loc Restriction ;
	//@Enumerated(EnumType.STRING )
		//private OrderStatus status;
	public enum Loc {
		SOLAPUR
		
	}
//------------------------------------------------------------------------
	@ManyToOne
	@JoinColumn(name="pollId")
    private PollName pollLocation;

	

	public int getLocationID() {
		return locationID;
	}

	public void setLocationID(int locationID) {
		this.locationID = locationID;
	}

	public Loc getRestriction() {
		return Restriction;
	}

	public void setRestriction(Loc restriction) {
		Restriction = restriction;
	}

	public PollName getPollLocation() {
		return pollLocation;
	}

	public void setPollLocation(PollName pollLocation) {
		this.pollLocation = pollLocation;
	}

	
	
	

}
