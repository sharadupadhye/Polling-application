package com.example.Poll10.repositories;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.Poll10.entity.PollOption;
import com.example.Poll10.entity.Vote;

@Repository
public interface VoteRepository extends JpaRepository <Vote,Integer>{
	
	//@Query("select count(s) from Strategy s where s.name=:name and s.username=:username")

	//@Query("SELECT EXISTS(SELECT v FROM Vote v WHERE polloption=:optId AND users=:userId")
	@Query("SELECT count(v)FROM Vote v WHERE option_id =:optId AND use_id=:userId")
	Integer voting(@Param("optId") Integer optId ,@Param("userId") Integer userId);
	
	//SELECT EXISTS(SELECT * FROM Vote v WHERE v.option_id = :optId AND v.use_id = :userId)
	//update Employee e set e.content = :content where e.id = :id
	//boolean existsVoteBypolloption(Integer opt);
	

}
