package com.example.Poll10.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Poll10.entity.AgeRestriction;
import com.example.Poll10.services.AgeRestrictionService;


@RestController
public class AgeRestrictionContoller {
	@Autowired
	private AgeRestrictionService ageRestrictionService;
	
	@PostMapping(value = "/saveAge")
	private int saveBook(@RequestBody AgeRestriction ageRec)  
	{  
		ageRestrictionService.saveOrUpdate(ageRec);  
	return  ageRec.getAgeId();  
	}
	
//	@GetMapping("/age/{id}")  
//	private Iterable<AgeRestriction> findByAge(@PathVariable("id") Integer ageid)  
//	{  
//		
//		//System.out.println(id);
//		ageRestrictionService.listAll(ageid);
//		return null;  
//	}
	

}
