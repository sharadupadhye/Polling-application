package com.example.Poll10.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.Poll10.entity.AgeRestriction;

@Repository
public interface AgeRestrictionRepository extends JpaRepository <AgeRestriction,Integer>{
	
	//@Query("select count(u.user_age) from Users u where useId=:ud")
	//Integer age(@Param("ud") Integer uId);
	//SELECT poll_id FROM poll10.agerestriction WHERE age_restriction=20;
	
	@Query("select p.pollId from AgeRestriction a inner join a.pollId p where a.ageRestriction=:ag")
	 Integer poll(@Param("ag") Integer age);

}


