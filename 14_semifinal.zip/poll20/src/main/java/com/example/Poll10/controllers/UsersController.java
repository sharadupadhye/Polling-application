package com.example.Poll10.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.example.Poll10.entity.Users;
import com.example.Poll10.services.UsersService;

@RestController
public class UsersController {
	@Autowired
	private UsersService usersService;
	
	@PostMapping(value = "/saveUsers")
	private int saveBook(@RequestBody Users user)  
	{  
		usersService.saveOrUpdate(user);  
	return  user.getUseId();  
	}


}
