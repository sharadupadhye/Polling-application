package com.example.Poll10.services;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.example.Poll10.entity.AgeRestriction;
import com.example.Poll10.repositories.AgeRestrictionRepository;
import com.example.Poll10.repositories.UsersRepository;


@Service
public class AgeRestrictionService {
	@Autowired
	private AgeRestrictionRepository ageRestrictionRepo;
	

	
	 public void saveOrUpdate(AgeRestriction ageRestriction)
	 {
		// System.out.println("You entered:= " + pollName);
		 ageRestrictionRepo.save(ageRestriction);
	 }
	 
//	 public Iterable<AgeRestriction> listAll(Integer id) {
//		 int a=usersRepo.age(id);
//		 
//		 int b=ageRestrictionRepo.poll(a);
//		 
//	      return this.ageRestrictionRepo.findAll();
//	 }

	

}
