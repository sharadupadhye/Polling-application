package com.example.Poll10.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Poll10.entity.AgeRestriction;
import com.example.Poll10.entity.PollName;
import com.example.Poll10.entity.PollOption;
import com.example.Poll10.entity.Users;
import com.example.Poll10.repositories.AgeRestrictionRepository;
import com.example.Poll10.repositories.PollOptionRepository;
import com.example.Poll10.repositories.UsersRepository;



@Service
public class PollOptionService {
@Autowired	
private PollOptionRepository pollOptRepo;

@Autowired
private AgeRestrictionRepository ageRestrictionRepo;

@Autowired
private UsersRepository usersRepo;

   public Iterable<PollOption> listAll() {
      return this.pollOptRepo.findAll();
     }

   public void saveOrUpdate(PollOption pollOption)
    {
	 //System.out.println("You entered:= " + pollName);
	   pollOptRepo.save(pollOption);
     }
   
   public PollOption getbyid(int id) {
		return pollOptRepo.findById(id).get();
		 
	 }
   
   public Iterable<PollOption> listAllAge(Integer id) {
	   System.out.println("value of id = "+id);
		 Integer a=usersRepo.age(id);
		 System.out.println("value of a = "+a);  
		 int b=  ageRestrictionRepo.poll(a);
		 System.out.println("value of b = "+b);
		 //return null;
		//return  List<AgeRestriction> b=ageRestrictionRepo.poll(a);
		// System.out.println("value of b = "+b);
	      return this.pollOptRepo.resList(b);
	 }
   
}
