package com.example.Poll10.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Poll10.entity.LocationRestriction;

@Repository
public interface LocationRestrictionRepository extends JpaRepository <LocationRestriction,Integer> {

}
