package com.example.Poll10.services;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Poll10.entity.PollOption;
import com.example.Poll10.entity.Users;
import com.example.Poll10.entity.Vote;
import com.example.Poll10.payload.VoteDto;
import com.example.Poll10.repositories.VoteRepository;

@Service
public class VoteService {
	@Autowired
	private VoteRepository voteRepo;
	@Autowired
	private ModelMapper modelMapper;
	@Autowired
    private UsersService usersService;
	@Autowired
	private PollOptionService pollOptionService;
	 public void saveOrUpdate(Vote vote)
	 {
		
		 voteRepo.save(vote);
	 }
	 public String search(VoteDto votedto,Integer a,Integer b)  
	 {  
		 int result=voteRepo.voting(a,b);
		if(result==0) {
			Users user=usersService.getbyid(a);
			PollOption poll=pollOptionService.getbyid(b);
		Vote vote=this.modelMapper.map(votedto,Vote.class);
			//saveOrUpdate( vote);
		vote.setUsers(user);
		vote.setPolloption(poll);
		this.voteRepo.save(vote);
			return "voting success";
		}
		 return "already voted";
			
	 }
	 
	 

}
