package com.example.Poll10.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.Poll10.entity.Users;
@Repository
public interface UsersRepository extends JpaRepository<Users,Integer> {
	
	//@Query("SELECT count(v)FROM Vote v WHERE option_id =:optId AND use_id=:userId")
	@Query("select u.user_age from Users u where use_id=:ud")
	Integer age(@Param("ud") Integer uId);
	
	//@Query("select count(r.React) from Reaction r where react='loved' and postid_postid=:p2")
	//Integer lovedcount(@Param("p2")long postid);

}
